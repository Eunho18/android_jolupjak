package com.example.jol_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ElectricityActivity extends AppCompatActivity implements View.OnClickListener {

    TextView  txt_price; //선택된 수량, 선택된 수량의 가격
    CheckBox chk_agree;
    EditText edit_count;

    int val_price; //총 결제금액
    int selected_count; //선택한 수량
    int selected_product = 1000;//선택한 수량의 가격


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electricity);

        edit_count = findViewById(R.id.edit_count);
        txt_price = findViewById(R.id.txt_price);
        chk_agree = findViewById(R.id.chk_agree);



        findViewById(R.id.btn_plus).setOnClickListener(this);
        findViewById(R.id.btn_minus).setOnClickListener(this);
        findViewById(R.id.btn_buy).setOnClickListener(this);
        findViewById(R.id.radio1).setOnClickListener(this);
        findViewById(R.id.radio2).setOnClickListener(this);
        findViewById(R.id.radio3).setOnClickListener(this);


        sumTotal();




    }
    void sumTotal(){

        selected_count = Integer.parseInt(edit_count.getText().toString()); //선택한 수량

        val_price = selected_product * selected_count; //총 금액 = 선택된 수량의 가격 * 선택한 수량

        txt_price.setText(val_price+" 원");


    }

    @Override
    public void onClick(View view) {

        String str_count = edit_count.getText().toString();
        int count = Integer.parseInt(str_count);

        switch (view.getId()){

            case R.id.radio1:
                selected_product = 1000;
                sumTotal();
                break;

            case R.id.radio2:
                selected_product = 2000;
                sumTotal();
                break;

            case R.id.radio3:
                selected_product = 3000;
                sumTotal();
                break;

            case R.id.radio4:
                selected_product = 5000;
                sumTotal();
                break;

            case R.id.radio5:
                selected_product = 10000;
                sumTotal();
                break;

            case R.id.radio6:
                selected_product = 100000;
                sumTotal();
                break;




            case R.id.btn_minus:
                if(count == 1){
                    Toast.makeText(this, "선택 수량을 확인하세요.", Toast.LENGTH_SHORT).show();

                }
                else{
                    edit_count.setText(Integer.toString(count-1));
                    sumTotal();
                }
                break;

            case R.id.btn_plus:
                edit_count.setText(Integer.toString(count+1));
                sumTotal();
                break;


            case R.id.btn_buy:
                if(chk_agree.isChecked()==true){
                    Toast.makeText(this, "총 구매 가격은"+val_price+"입니다 결제창으로 넘어갑니다.", Toast.LENGTH_SHORT).show();
                    Intent GoPayment = new Intent(ElectricityActivity.this, PaymentActivity.class);
                    startActivity(GoPayment);
                }
                else{
                    Toast.makeText(this, "결제 동의 버튼을 체크해 주세요.", Toast.LENGTH_SHORT).show();
                }
                break;


        }



    }
}