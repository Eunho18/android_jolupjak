package com.example.mybluetooth;

import static com.example.mybluetooth.MainActivity.mConnectedThread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        this.findViewById(R.id.btn_send3).setOnClickListener((View.OnClickListener) v -> {
            if(mConnectedThread != null) //First check to make sure thread created
                mConnectedThread.write("0");
        });
        this.findViewById(R.id.btn_send4).setOnClickListener((View.OnClickListener) v -> {
            if(mConnectedThread != null) //First check to make sure thread created
                mConnectedThread.write("1");
        });
    }
}