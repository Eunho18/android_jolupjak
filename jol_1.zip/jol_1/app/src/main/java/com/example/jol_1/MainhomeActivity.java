package com.example.jol_1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainhomeActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        findViewById(R.id.btn_mypage).setOnClickListener(this);
        findViewById(R.id.btn_Go_electricty).setOnClickListener(this);
        findViewById(R.id.naver_car).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_mypage:
                Intent intent_mypage = new Intent(MainhomeActivity.this,MypageActivity.class);
                startActivity(intent_mypage);
                break;

            case R.id.btn_Go_electricty:
                Intent intent_electrity = new Intent(MainhomeActivity.this, ElectricityActivity.class);
                startActivity(intent_electrity);
                break;

            case R.id.naver_car:
                Intent intent_car = new Intent(Intent.ACTION_VIEW);
                intent_car.setData(Uri.parse("https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=1&acr=2&acq=%EC%A0%84%EA%B8%B0%EC%B0%A8&qdt=0&ie=utf8&query=%EC%A0%84%EA%B8%B0%EC%B0%A8"));
                startActivity(intent_car);
                break;




        }


    }
}

